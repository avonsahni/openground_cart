'use strict';
const express  = require('express');
const router   = express.Router();
const bcrypt   = require('bcryptjs');
const path     = require('path');
const fs       = require('fs');
const db       = require('../db/database');
const mailer   = require('../services/mailer');
const { requireAdmin } = require('../middleware/auth');
const { makeUpload }   = require('../middleware/upload');

const postUpload    = makeUpload('posts');
const pageUpload    = makeUpload('pages');
const productUpload = makeUpload('products');

// Flash helper
function flash(req, type, msg) { req.session.flash = { type, msg }; }

// ── Login / Logout ─────────────────────────────────────────────────
router.get('/', (req, res) => res.redirect('/admin/dashboard'));

router.get('/login', (req, res) => {
  if (req.session.adminId) return res.redirect('/admin/dashboard');
  res.render('admin/login', { title: 'Admin Login', error: null });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const admin = db.getAdmin(username);
  if (!admin || !bcrypt.compareSync(password, admin.password)) {
    return res.render('admin/login', { title: 'Admin Login', error: 'Invalid username or password.' });
  }
  req.session.adminId       = admin.id;
  req.session.adminUsername = admin.username;
  res.redirect('/admin/dashboard');
});

router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/admin/login');
});

// All routes below require login
router.use(requireAdmin);

// ── Dashboard ──────────────────────────────────────────────────────
router.get('/dashboard', (req, res) => {
  const flash = req.session.flash || null;
  delete req.session.flash;
  res.render('admin/dashboard', {
    title: 'Dashboard', stats: db.getStats(),
    recentPosts: db.getAllPosts().slice(0, 5),
    recentContacts: db.getAllContacts().slice(0, 5),
    flash,
  });
});

// ── Posts ──────────────────────────────────────────────────────────
router.get('/posts', (req, res) => {
  const flash = req.session.flash || null; delete req.session.flash;
  res.render('admin/posts', { title: 'Posts', posts: db.getAllPosts(), flash });
});

router.get('/posts/new', (req, res) => {
  res.render('admin/post-editor', { title: 'New Post', post: null, errors: [] });
});

router.post('/posts/new', postUpload.single('photo'), (req, res) => {
  const { title, slug, excerpt, body, status } = req.body;
  const errors = [];
  if (!title || title.trim().length < 2) errors.push('Title is required.');
  if (errors.length > 0) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.render('admin/post-editor', { title: 'New Post', post: req.body, errors });
  }
  const photo = req.file ? `/uploads/posts/${req.file.filename}` : null;
  try {
    const id = db.createPost({ title: title.trim(), slug: slug.trim()||'', excerpt: excerpt||'', body: body||'', photo, status, comments_enabled: req.body.comments_enabled ? 1 : 0 });
    flash(req, 'success', 'Post saved.');
    res.redirect(`/admin/posts/${id}/edit`);
  } catch (e) {
    const msg = e.message.includes('UNIQUE') ? 'That slug is already taken.' : 'Error saving post.';
    res.render('admin/post-editor', { title: 'New Post', post: req.body, errors: [msg] });
  }
});

router.get('/posts/:id/edit', (req, res) => {
  const post = db.getPostById(req.params.id);
  if (!post) { flash(req, 'error', 'Post not found.'); return res.redirect('/admin/posts'); }
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/post-editor', { title: `Edit: ${post.title}`, post, errors: [], flash: f });
});

router.post('/posts/:id/edit', postUpload.single('photo'), (req, res) => {
  const post   = db.getPostById(req.params.id);
  if (!post) return res.redirect('/admin/posts');
  const { title, slug, excerpt, body, status } = req.body;
  const errors = [];
  if (!title || title.trim().length < 2) errors.push('Title is required.');
  if (errors.length > 0) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.render('admin/post-editor', { title: 'Edit Post', post: { ...req.body, id: post.id }, errors, flash: null });
  }
  const photo = req.file ? `/uploads/posts/${req.file.filename}` : post.photo;
  db.updatePost(req.params.id, { title: title.trim(), slug: slug.trim()||'', excerpt: excerpt||'', body: body||'', photo, status, comments_enabled: req.body.comments_enabled ? 1 : 0 });
  flash(req, 'success', 'Post updated.');
  res.redirect(`/admin/posts/${req.params.id}/edit`);
});

router.post('/posts/:id/delete', (req, res) => {
  db.deletePost(req.params.id);
  flash(req, 'success', 'Post deleted.');
  res.redirect('/admin/posts');
});

// ── Pages ──────────────────────────────────────────────────────────
router.get('/pages', (req, res) => {
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/pages', { title: 'Pages', pages: db.getAllPages(), flash: f });
});

router.get('/pages/new', (req, res) => {
  res.render('admin/page-editor', { title: 'New Page', page: null, errors: [] });
});

router.post('/pages/new', pageUpload.single('photo'), (req, res) => {
  const { title, slug, body, in_nav, nav_label, nav_order, is_active } = req.body;
  const errors = [];
  if (!title || title.trim().length < 2) errors.push('Title is required.');
  if (errors.length > 0) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.render('admin/page-editor', { title: 'New Page', page: req.body, errors });
  }
  const photo = req.file ? `/uploads/pages/${req.file.filename}` : null;
  try {
    const id = db.createPage({ title: title.trim(), slug: slug.trim()||'', body: body||'', photo, in_nav: in_nav==='on', nav_label: nav_label||title, nav_order: parseInt(nav_order)||99, is_active: is_active==='on' });
    flash(req, 'success', 'Page created.');
    res.redirect(`/admin/pages/${id}/edit`);
  } catch (e) {
    const msg = e.message.includes('UNIQUE') ? 'That slug is already taken.' : 'Error saving page.';
    res.render('admin/page-editor', { title: 'New Page', page: req.body, errors: [msg] });
  }
});

router.get('/pages/:id/edit', (req, res) => {
  const page = db.getPageById(req.params.id);
  if (!page) { flash(req, 'error', 'Page not found.'); return res.redirect('/admin/pages'); }
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/page-editor', { title: `Edit: ${page.title}`, page, errors: [], flash: f });
});

router.post('/pages/:id/edit', pageUpload.single('photo'), (req, res) => {
  const page = db.getPageById(req.params.id);
  if (!page) return res.redirect('/admin/pages');
  const { title, slug, body, in_nav, nav_label, nav_order, is_active } = req.body;
  const errors = [];
  if (!title || title.trim().length < 2) errors.push('Title is required.');
  if (errors.length > 0) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.render('admin/page-editor', { title: 'Edit Page', page: { ...req.body, id: page.id }, errors, flash: null });
  }
  const photo = req.file ? `/uploads/pages/${req.file.filename}` : page.photo;
  db.updatePage(req.params.id, { title: title.trim(), slug: slug.trim()||'', body: body||'', photo, in_nav: in_nav==='on', nav_label: nav_label||title, nav_order: parseInt(nav_order)||99, is_active: is_active==='on' });
  flash(req, 'success', 'Page updated.');
  res.redirect(`/admin/pages/${req.params.id}/edit`);
});

router.post('/pages/:id/delete', (req, res) => {
  db.deletePage(req.params.id);
  flash(req, 'success', 'Page deleted.');
  res.redirect('/admin/pages');
});

// ── Navigation ─────────────────────────────────────────────────────
router.get('/nav', (req, res) => {
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/nav', { title: 'Navigation', items: db.getAllNavItems(), flash: f });
});

router.post('/nav/add', (req, res) => {
  const { label, url, sort_order, opens_new } = req.body;
  if (label && url) db.createNavItem({ label: label.trim(), url: url.trim(), sort_order: parseInt(sort_order)||99, is_active: true, opens_new: opens_new==='on' });
  flash(req, 'success', 'Nav item added.');
  res.redirect('/admin/nav');
});

router.post('/nav/:id/edit', (req, res) => {
  const { label, url, sort_order, is_active, opens_new } = req.body;
  db.updateNavItem(req.params.id, { label: label.trim(), url: url.trim(), sort_order: parseInt(sort_order)||99, is_active: is_active==='on', opens_new: opens_new==='on' });
  flash(req, 'success', 'Nav updated.');
  res.redirect('/admin/nav');
});

router.post('/nav/:id/delete', (req, res) => {
  db.deleteNavItem(req.params.id);
  flash(req, 'success', 'Nav item removed.');
  res.redirect('/admin/nav');
});

// ── Subscribers ────────────────────────────────────────────────────
router.get('/subscribers', (req, res) => {
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/subscribers', { title: 'Subscribers', subscribers: db.getAllSubscribers(), flash: f });
});

router.post('/subscribers/:id/delete', (req, res) => {
  db.deleteSubscriber(req.params.id);
  flash(req, 'success', 'Subscriber removed.');
  res.redirect('/admin/subscribers');
});

// ── Contacts ───────────────────────────────────────────────────────
router.get('/contacts', (req, res) => {
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/contacts', { title: 'Messages', contacts: db.getAllContacts(), flash: f });
});

router.post('/contacts/:id/read', (req, res) => {
  db.markContactRead(req.params.id);
  res.redirect('/admin/contacts');
});

router.post('/contacts/:id/delete', (req, res) => {
  db.deleteContact(req.params.id);
  flash(req, 'success', 'Message deleted.');
  res.redirect('/admin/contacts');
});

// ── Shop — Products ────────────────────────────────────────────────
router.get('/shop', (req, res) => {
  const f = req.session.flash || null; delete req.session.flash;
  const s = db.getAllSettings();
  res.render('admin/shop', { title: 'Shop', products: db.getAllProducts(), shopEnabled: s.shop_enabled === '1', flash: f });
});

router.post('/shop/toggle', (req, res) => {
  const s = db.getAllSettings();
  db.updateSettings({ shop_enabled: s.shop_enabled === '1' ? '0' : '1' });
  flash(req, 'success', `Shop ${s.shop_enabled === '1' ? 'disabled' : 'enabled'}.`);
  res.redirect('/admin/shop');
});

router.get('/shop/new', (req, res) => {
  res.render('admin/product-editor', { title: 'New Product', product: null, errors: [] });
});

router.post('/shop/new', productUpload.single('photo'), (req, res) => {
  const { name, slug, description, price, stock, is_active, sort_order } = req.body;
  const errors = [];
  if (!name || name.trim().length < 2) errors.push('Product name is required.');
  if (!price || isNaN(price))          errors.push('Price is required.');
  if (errors.length > 0) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.render('admin/product-editor', { title: 'New Product', product: req.body, errors });
  }
  const photo = req.file ? `/uploads/products/${req.file.filename}` : null;
  try {
    const id = db.createProduct({ name: name.trim(), slug: slug.trim()||'', description: description||'', price: parseInt(price), photo, stock: parseInt(stock??-1), is_active: is_active==='on', sort_order: parseInt(sort_order)||0 });
    flash(req, 'success', 'Product created.');
    res.redirect(`/admin/shop/${id}/edit`);
  } catch (e) {
    const msg = e.message.includes('UNIQUE') ? 'That slug is already taken.' : 'Error saving product.';
    res.render('admin/product-editor', { title: 'New Product', product: req.body, errors: [msg] });
  }
});

router.get('/shop/:id/edit', (req, res) => {
  const product = db.getProductById(req.params.id);
  if (!product) { flash(req, 'error', 'Product not found.'); return res.redirect('/admin/shop'); }
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/product-editor', { title: `Edit: ${product.name}`, product, errors: [], flash: f });
});

router.post('/shop/:id/edit', productUpload.single('photo'), (req, res) => {
  const product = db.getProductById(req.params.id);
  if (!product) return res.redirect('/admin/shop');
  const { name, slug, description, price, stock, is_active, sort_order } = req.body;
  const photo = req.file ? `/uploads/products/${req.file.filename}` : product.photo;
  db.updateProduct(req.params.id, { name: name.trim(), slug: slug.trim()||'', description: description||'', price: parseInt(price)||0, photo, stock: parseInt(stock??-1), is_active: is_active==='on', sort_order: parseInt(sort_order)||0 });
  flash(req, 'success', 'Product updated.');
  res.redirect(`/admin/shop/${req.params.id}/edit`);
});

router.post('/shop/:id/delete', (req, res) => {
  db.deleteProduct(req.params.id);
  flash(req, 'success', 'Product deleted.');
  res.redirect('/admin/shop');
});

// ── Orders ─────────────────────────────────────────────────────────
router.get('/orders', (req, res) => {
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/orders', { title: 'Orders', orders: db.getAllOrders(), flash: f });
});

router.get('/orders/:id', (req, res) => {
  const order = db.getOrderById(req.params.id);
  if (!order) { flash(req, 'error', 'Order not found.'); return res.redirect('/admin/orders'); }
  order.items = JSON.parse(order.items_json || '[]');
  res.render('admin/order-detail', { title: `Order ${order.order_ref}`, order });
});

router.post('/orders/:id/status', (req, res) => {
  const { status, payment_ref } = req.body;
  db.updateOrderStatus(req.params.id, status, payment_ref||null);
  flash(req, 'success', 'Order updated.');
  res.redirect(`/admin/orders/${req.params.id}`);
});

router.post('/orders/:id/delete', (req, res) => {
  db.deleteOrder(req.params.id);
  flash(req, 'success', 'Order deleted.');
  res.redirect('/admin/orders');
});

// ── Settings ───────────────────────────────────────────────────────
router.get('/settings', (req, res) => {
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/settings', { title: 'Settings', site: db.getAllSettings(), flash: f });
});

router.post('/settings', (req, res) => {
  const allowed = ['site_title','site_tagline','site_url','author_name','about_text','footer_text','upi_id','shop_title','razorpay_enabled','comments_enabled'];
  const data = {};
  for (const k of allowed) {
    if (k === 'comments_enabled') { data[k] = req.body[k] === 'on' ? '1' : '0'; }
    else if (req.body[k] !== undefined) data[k] = req.body[k];
  }
  db.updateSettings(data);
  flash(req, 'success', 'Settings saved.');
  res.redirect('/admin/settings');
});

router.get('/password', (req, res) => {
  const f = req.session.flash || null; delete req.session.flash;
  res.render('admin/password', { title: 'Change Password', flash: f, error: null });
});

router.post('/password', (req, res) => {
  const { current, newpass, confirm } = req.body;
  const admin = db.getAdmin(req.session.adminUsername);
  if (!bcrypt.compareSync(current, admin.password)) {
    return res.render('admin/password', { title: 'Change Password', flash: null, error: 'Current password is incorrect.' });
  }
  if (newpass.length < 8) {
    return res.render('admin/password', { title: 'Change Password', flash: null, error: 'New password must be at least 8 characters.' });
  }
  if (newpass !== confirm) {
    return res.render('admin/password', { title: 'Change Password', flash: null, error: 'Passwords do not match.' });
  }
  db.updateAdminPassword(admin.id, newpass);
  flash(req, 'success', 'Password changed.');
  res.redirect('/admin/settings');
});

module.exports = router;

// ── Subscriptions ──────────────────────────────────────────────────
const plans = require('../db/plans');

router.get('/subscriptions', (req, res) => {
  const f = req.session.flash || null; delete req.session.flash;
  const Database = require('better-sqlite3');
  const dbRaw = new Database(require('path').join(__dirname,'..','data','openground.db'));
  plans.initPlans(dbRaw);
  res.render('admin/subscriptions', {
    title: 'Subscriptions',
    allPlans: plans.getAllPlans(dbRaw),
    orders: plans.getAllPlanOrders(dbRaw),
    flash: f,
  });
  dbRaw.close();
});

router.post('/subscriptions/:id/toggle', (req, res) => {
  const Database = require('better-sqlite3');
  const dbRaw = new Database(require('path').join(__dirname,'..','data','openground.db'));
  plans.initPlans(dbRaw);
  const plan = plans.togglePlan(dbRaw, req.params.id);
  flash(req, 'success', `"${plan.name}" is now ${plan.is_active ? 'LIVE' : 'offline'}.`);
  dbRaw.close();
  res.redirect('/admin/subscriptions');
});

router.post('/subscriptions/:id/update', (req, res) => {
  const Database = require('better-sqlite3');
  const dbRaw = new Database(require('path').join(__dirname,'..','data','openground.db'));
  plans.initPlans(dbRaw);
  plans.updatePlan(dbRaw, req.params.id, req.body);
  flash(req, 'success', 'Plan updated.');
  dbRaw.close();
  res.redirect('/admin/subscriptions');
});

router.post('/subscriptions/orders/:id/status', (req, res) => {
  const Database = require('better-sqlite3');
  const dbRaw = new Database(require('path').join(__dirname,'..','data','openground.db'));
  plans.initPlans(dbRaw);
  plans.updatePlanOrderStatus(dbRaw, req.params.id, req.body.status, req.body.payment_ref||null);
  flash(req, 'success', 'Order updated.');
  dbRaw.close();
  res.redirect('/admin/subscriptions');
});

router.post('/subscriptions/orders/:id/delete', (req, res) => {
  const Database = require('better-sqlite3');
  const dbRaw = new Database(require('path').join(__dirname,'..','data','openground.db'));
  plans.initPlans(dbRaw);
  plans.deletePlanOrder(dbRaw, req.params.id);
  flash(req, 'success', 'Order deleted.');
  dbRaw.close();
  res.redirect('/admin/subscriptions');
});
