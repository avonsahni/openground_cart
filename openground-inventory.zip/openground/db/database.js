'use strict';
const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');
const bcrypt   = require('bcryptjs');
const crypto   = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH  = process.env.DB_PATH || path.join(DATA_DIR, 'openground.db');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

let db;

function init() {
  db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  // Safe migrations
  const safeAlter = (sql) => { try { db.exec(sql); } catch(e) {} };
  safeAlter("ALTER TABLE posts ADD COLUMN comments_enabled INTEGER DEFAULT 1");
  safeAlter("ALTER TABLE orders ADD COLUMN admin_notes TEXT DEFAULT NULL");

  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS nav_items (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      label      TEXT NOT NULL,
      url        TEXT NOT NULL,
      sort_order INTEGER DEFAULT 0,
      is_active  INTEGER DEFAULT 1,
      opens_new  INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS posts (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      title        TEXT NOT NULL,
      slug         TEXT UNIQUE NOT NULL,
      excerpt      TEXT,
      body         TEXT,
      photo        TEXT,
      status       TEXT DEFAULT 'draft',
      created_at   TEXT DEFAULT (datetime('now')),
      updated_at   TEXT DEFAULT (datetime('now')),
      published_at TEXT
    );

    CREATE TABLE IF NOT EXISTS pages (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      title      TEXT NOT NULL,
      slug       TEXT UNIQUE NOT NULL,
      body       TEXT,
      photo      TEXT,
      in_nav     INTEGER DEFAULT 0,
      nav_label  TEXT,
      nav_order  INTEGER DEFAULT 99,
      is_active  INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS subscribers (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      email             TEXT UNIQUE NOT NULL,
      name              TEXT,
      status            TEXT DEFAULT 'active',
      unsubscribe_token TEXT UNIQUE,
      created_at        TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS contacts (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT NOT NULL,
      email      TEXT NOT NULL,
      message    TEXT NOT NULL,
      is_read    INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS admins (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      username   TEXT UNIQUE NOT NULL,
      password   TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS products (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT NOT NULL,
      slug        TEXT UNIQUE NOT NULL,
      description TEXT,
      price       INTEGER NOT NULL DEFAULT 0,
      photo       TEXT,
      stock       INTEGER DEFAULT -1,
      is_active   INTEGER DEFAULT 0,
      sort_order  INTEGER DEFAULT 0,
      created_at  TEXT DEFAULT (datetime('now')),
      updated_at  TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS orders (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      order_ref       TEXT UNIQUE NOT NULL,
      buyer_name      TEXT NOT NULL,
      buyer_email     TEXT NOT NULL,
      buyer_phone     TEXT,
      buyer_address   TEXT,
      items_json      TEXT NOT NULL,
      total           INTEGER NOT NULL,
      payment_method  TEXT DEFAULT 'upi',
      payment_ref     TEXT,
      gateway_order   TEXT,
      gateway_payment TEXT,
      status          TEXT DEFAULT 'pending',
      notes           TEXT,
      created_at      TEXT DEFAULT (datetime('now')),
      updated_at      TEXT DEFAULT (datetime('now'))
    );
  `);

  // Default settings
  const defaults = {
    site_title:       'Open Ground',
    site_tagline:     'Curious questions. Careful answers.',
    site_url:         '',
    author_name:      'Avon',
    about_text:       '',
    shop_enabled:     '0',
    shop_title:       'Shop',
    razorpay_enabled: '0',
    upi_id:           '',
    currency:         'INR',
    footer_text:      '',
    comments_enabled: '1',
  };
  const ins = db.prepare('INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)');
  for (const [k, v] of Object.entries(defaults)) ins.run(k, v);

  // Default nav
  const navCount = db.prepare('SELECT COUNT(*) as c FROM nav_items').get().c;
  if (navCount === 0) {
    const insNav = db.prepare('INSERT INTO nav_items (label,url,sort_order,is_active) VALUES (?,?,?,1)');
    insNav.run('Home',     '/',        1);
    insNav.run('Writing',  '/writing', 2);
    insNav.run('About',    '/about',   3);
    insNav.run('Contact',  '/contact', 4);
  }

  // Default admin
  if (!db.prepare('SELECT id FROM admins WHERE username=?').get('admin')) {
    const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'openground2026', 12);
    db.prepare('INSERT INTO admins (username,password) VALUES (?,?)').run('admin', hash);
    console.log('  Admin: admin / openground2026  — change this immediately.\n');
  }

  console.log('  Database ready.\n');
}

// ── Helpers ────────────────────────────────────────────────────────
function slugify(str) {
  return (str || '').toLowerCase()
    .replace(/[^\w\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').trim();
}

// ── Settings ───────────────────────────────────────────────────────
function getSetting(k)    { return db.prepare('SELECT value FROM settings WHERE key=?').get(k)?.value ?? null; }
function getAllSettings()  { return Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(r=>[r.key,r.value])); }
function updateSettings(d){ const s=db.prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)'); for(const[k,v] of Object.entries(d)) s.run(k,v); }

// ── Nav ────────────────────────────────────────────────────────────
function getNavItems()       { return db.prepare('SELECT * FROM nav_items WHERE is_active=1 ORDER BY sort_order ASC').all(); }
function getAllNavItems()     { return db.prepare('SELECT * FROM nav_items ORDER BY sort_order ASC').all(); }
function createNavItem(d)    { db.prepare('INSERT INTO nav_items (label,url,sort_order,is_active,opens_new) VALUES (?,?,?,?,?)').run(d.label,d.url,d.sort_order||99,d.is_active?1:0,d.opens_new?1:0); }
function updateNavItem(id,d) { db.prepare('UPDATE nav_items SET label=?,url=?,sort_order=?,is_active=?,opens_new=? WHERE id=?').run(d.label,d.url,d.sort_order||99,d.is_active?1:0,d.opens_new?1:0,id); }
function deleteNavItem(id)   { db.prepare('DELETE FROM nav_items WHERE id=?').run(id); }

// ── Posts ──────────────────────────────────────────────────────────
function getAllPosts()       { return db.prepare('SELECT id,title,slug,excerpt,photo,status,published_at,created_at FROM posts ORDER BY created_at DESC').all(); }
function getPublishedPosts() { return db.prepare('SELECT id,title,slug,excerpt,photo,published_at FROM posts WHERE status=? ORDER BY published_at DESC').all('published'); }
function getPostBySlug(s)    { return db.prepare('SELECT * FROM posts WHERE slug=?').get(s); }
function getPostById(id)     { return db.prepare('SELECT * FROM posts WHERE id=?').get(id); }

function createPost(d) {
  const slug = d.slug || slugify(d.title);
  return db.prepare('INSERT INTO posts (title,slug,excerpt,body,photo,status,published_at) VALUES (?,?,?,?,?,?,?)')
    .run(d.title, slug, d.excerpt||null, d.body||null, d.photo||null,
         d.status||'draft', d.status==='published'?new Date().toISOString():null).lastInsertRowid;
}

function updatePost(id, d) {
  const existing = getPostById(id);
  db.prepare(`UPDATE posts SET title=?,slug=?,excerpt=?,body=?,photo=?,status=?,published_at=?,updated_at=datetime('now') WHERE id=?`)
    .run(d.title, d.slug||slugify(d.title), d.excerpt||null, d.body||null, d.photo||null,
         d.status||'draft',
         d.status==='published'?(existing?.published_at||new Date().toISOString()):null,
         id);
}

function deletePost(id) { db.prepare('DELETE FROM posts WHERE id=?').run(id); }

// ── Pages ──────────────────────────────────────────────────────────
function getAllPages()      { return db.prepare('SELECT * FROM pages ORDER BY created_at DESC').all(); }
function getActivePage(s)  { return db.prepare('SELECT * FROM pages WHERE slug=? AND is_active=1').get(s); }
function getPageById(id)   { return db.prepare('SELECT * FROM pages WHERE id=?').get(id); }
function getNavPages()     { return db.prepare('SELECT * FROM pages WHERE in_nav=1 AND is_active=1 ORDER BY nav_order ASC').all(); }

function createPage(d) {
  const slug = d.slug || slugify(d.title);
  return db.prepare('INSERT INTO pages (title,slug,body,photo,in_nav,nav_label,nav_order,is_active) VALUES (?,?,?,?,?,?,?,?)')
    .run(d.title, slug, d.body||null, d.photo||null,
         d.in_nav?1:0, d.nav_label||d.title, d.nav_order||99, d.is_active?1:0).lastInsertRowid;
}

function updatePage(id, d) {
  db.prepare(`UPDATE pages SET title=?,slug=?,body=?,photo=?,in_nav=?,nav_label=?,nav_order=?,is_active=?,updated_at=datetime('now') WHERE id=?`)
    .run(d.title, d.slug||slugify(d.title), d.body||null, d.photo||null,
         d.in_nav?1:0, d.nav_label||d.title, d.nav_order||99, d.is_active?1:0, id);
}

function deletePage(id) { db.prepare('DELETE FROM pages WHERE id=?').run(id); }

// ── Subscribers ────────────────────────────────────────────────────
function addSubscriber(email, name) {
  const existing = db.prepare('SELECT * FROM subscribers WHERE email=?').get(email.toLowerCase());
  if (existing) {
    if (existing.status === 'unsubscribed') {
      db.prepare(`UPDATE subscribers SET status='active',name=? WHERE id=?`).run(name||existing.name, existing.id);
      return { ok: true, reactivated: true, subscriber: db.prepare('SELECT * FROM subscribers WHERE id=?').get(existing.id) };
    }
    return { ok: false, reason: 'already_subscribed' };
  }
  const token = crypto.randomBytes(32).toString('hex');
  const id = db.prepare('INSERT INTO subscribers (email,name,unsubscribe_token) VALUES (?,?,?)')
    .run(email.toLowerCase(), name||null, token).lastInsertRowid;
  return { ok: true, subscriber: db.prepare('SELECT * FROM subscribers WHERE id=?').get(id) };
}

function getAllSubscribers()      { return db.prepare(`SELECT * FROM subscribers ORDER BY created_at DESC`).all(); }
function unsubscribeByToken(tok) { const s=db.prepare('SELECT * FROM subscribers WHERE unsubscribe_token=?').get(tok); if(s) db.prepare(`UPDATE subscribers SET status='unsubscribed' WHERE id=?`).run(s.id); return s||null; }
function deleteSubscriber(id)    { db.prepare('DELETE FROM subscribers WHERE id=?').run(id); }

// ── Contacts ───────────────────────────────────────────────────────
function addContact(name,email,message) { return db.prepare('INSERT INTO contacts(name,email,message) VALUES(?,?,?)').run(name,email,message).lastInsertRowid; }
function getAllContacts()  { return db.prepare('SELECT * FROM contacts ORDER BY created_at DESC').all(); }
function markContactRead(id) { db.prepare('UPDATE contacts SET is_read=1 WHERE id=?').run(id); }
function deleteContact(id)   { db.prepare('DELETE FROM contacts WHERE id=?').run(id); }

// ── Admin ──────────────────────────────────────────────────────────
function getAdmin(username)       { return db.prepare('SELECT * FROM admins WHERE username=?').get(username); }
function updateAdminPassword(id,p){ db.prepare('UPDATE admins SET password=? WHERE id=?').run(bcrypt.hashSync(p,12),id); }

// ── Products ───────────────────────────────────────────────────────
function getAllProducts(activeOnly=false) {
  return activeOnly
    ? db.prepare('SELECT * FROM products WHERE is_active=1 ORDER BY sort_order ASC').all()
    : db.prepare('SELECT * FROM products ORDER BY sort_order ASC').all();
}
function getProductBySlug(s) { return db.prepare('SELECT * FROM products WHERE slug=?').get(s); }
function getProductById(id)  { return db.prepare('SELECT * FROM products WHERE id=?').get(id); }
function createProduct(d)    { return db.prepare('INSERT INTO products (name,slug,description,price,photo,stock,is_active,sort_order) VALUES (?,?,?,?,?,?,?,?)').run(d.name, d.slug||slugify(d.name), d.description||null, d.price||0, d.photo||null, d.stock??-1, d.is_active?1:0, d.sort_order||0).lastInsertRowid; }
function updateProduct(id,d) { db.prepare(`UPDATE products SET name=?,slug=?,description=?,price=?,photo=?,stock=?,is_active=?,sort_order=?,updated_at=datetime('now') WHERE id=?`).run(d.name, d.slug||slugify(d.name), d.description||null, d.price||0, d.photo||null, d.stock??-1, d.is_active?1:0, d.sort_order||0, id); }
function deleteProduct(id)   { db.prepare('DELETE FROM products WHERE id=?').run(id); }

// ── Orders ─────────────────────────────────────────────────────────
function createOrder(d) {
  const ref = 'OG-' + Date.now() + '-' + crypto.randomBytes(3).toString('hex').toUpperCase();
  // Use a transaction — deduct stock atomically with order creation
  const run = db.transaction(() => {
    // Check stock and deduct for each item
    for (const item of d.items) {
      const product = db.prepare('SELECT stock FROM products WHERE id=?').get(item.id);
      if (product && product.stock !== -1) {
        if (product.stock < item.qty) throw new Error('Insufficient stock for: ' + item.name);
        db.prepare('UPDATE products SET stock=stock-? WHERE id=? AND stock != -1').run(item.qty, item.id);
      }
    }
    return db.prepare('INSERT INTO orders (order_ref,buyer_name,buyer_email,buyer_phone,buyer_address,items_json,total,payment_method,notes) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(ref, d.buyer_name, d.buyer_email, d.buyer_phone||null, d.buyer_address||null,
           JSON.stringify(d.items), d.total, d.payment_method||'upi', d.notes||null).lastInsertRowid;
  });
  return run();
}
function getAllOrders()           { return db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all(); }
function getOrderById(id)        { return db.prepare('SELECT * FROM orders WHERE id=?').get(id); }
function getOrderByRef(ref)      { return db.prepare('SELECT * FROM orders WHERE order_ref=?').get(ref); }
function updateOrderStatus(id, s, ref) {
  const order = getOrderById(id);
  // Restore stock if cancelling or refunding a non-cancelled order
  if (order && ['cancelled','refunded'].includes(s) && !['cancelled','refunded'].includes(order.status)) {
    try {
      const items = JSON.parse(order.items_json || '[]');
      for (const item of items) {
        db.prepare('UPDATE products SET stock=stock+? WHERE id=? AND stock != -1').run(item.qty, item.id);
      }
    } catch(e) {}
  }
  db.prepare(`UPDATE orders SET status=?,payment_ref=COALESCE(?,payment_ref),updated_at=datetime('now') WHERE id=?`).run(s, ref||null, id);
}
function deleteOrder(id)         { db.prepare('DELETE FROM orders WHERE id=?').run(id); }

// ── Dashboard stats ────────────────────────────────────────────────
function getStats() {
  return {
    published:   db.prepare(`SELECT COUNT(*) c FROM posts WHERE status='published'`).get().c,
    drafts:      db.prepare(`SELECT COUNT(*) c FROM posts WHERE status='draft'`).get().c,
    subscribers: db.prepare(`SELECT COUNT(*) c FROM subscribers WHERE status='active'`).get().c,
    unread:      db.prepare(`SELECT COUNT(*) c FROM contacts WHERE is_read=0`).get().c,
    orders:      db.prepare(`SELECT COUNT(*) c FROM orders WHERE status='pending'`).get().c,
    revenue:     db.prepare(`SELECT COALESCE(SUM(total),0) t FROM orders WHERE status='confirmed'`).get().t,
  };
}

module.exports = {
  init, slugify,
  getSetting, getAllSettings, updateSettings,
  getNavItems, getAllNavItems, createNavItem, updateNavItem, deleteNavItem,
  getAllPosts, getPublishedPosts, getPostBySlug, getPostById, createPost, updatePost, deletePost,
  getAllPages, getActivePage, getPageById, getNavPages, createPage, updatePage, deletePage,
  addSubscriber, getAllSubscribers, unsubscribeByToken, deleteSubscriber,
  addContact, getAllContacts, markContactRead, deleteContact,
  getAdmin, updateAdminPassword,
  getAllProducts, getProductBySlug, getProductById, createProduct, updateProduct, deleteProduct,
  createOrder, getAllOrders, getOrderById, getOrderByRef, updateOrderStatus, deleteOrder,
  getStats,
};
